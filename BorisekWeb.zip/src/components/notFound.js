import React from "react";

const NotFound = () => {
  return (
    <div>
      <p>NOT FOUND</p>
    </div>
  );
};

export default NotFound;
